import logging
import time
import sqlite3
import aiogram
import configparser

from aiogram import executor, types
from aiogram.dispatcher.filters import AdminFilter, IsReplyFilter

from config import adminId
from random import randint
from misc import bot, dp
from aiogram.dispatcher import FSMContext
from aiogram import Bot, Dispatcher
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.filters import Command, ChatTypeFilter, AdminFilter
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.types import ChatPermissions
from config import ADMIN_ID
from aiogram.dispatcher.filters import Text


# Создаем базу данных для хранения предупреждений
conn = sqlite3.connect('warnings.db')
cursor = conn.cursor()
cursor.execute('''CREATE TABLE IF NOT EXISTS warnings
                  (user_id INTEGER PRIMARY KEY, username TEXT, fullname TEXT, count INTEGER)''')
conn.commit()

admins = "5175857543, 1176110216"

# Send admin message about bot started
async def send_adm(*args, **kwargs):
    await bot.send_message(chat_id=adminId, text='еби меня нежно!')

# Создаем состояние для удаления сообщения с командой /warn
class WarnState(StatesGroup):
    delete = State()

# Функция для получения информации о пользователе
async def get_user_info(user: types.User):
    if user.username:
        return user.username
    else:
        return user.full_name

# Функция для отправки сообщения в чат
async def send_message(chat_id: int, text: str):
    await bot.send_message(chat_id=chat_id, text=text)

# Функция для обновления количества предупреждений в базе данных
def update_warnings(user_id: int, username: str, fullname: str, count: int):
    cursor.execute("INSERT OR REPLACE INTO warnings (user_id, username, fullname, count) VALUES (?, ?, ?, ?)",
                   (user_id, username, fullname, count))
    conn.commit()

# Обработчик команды /warn
@dp.message_handler(Command("warn"), ChatTypeFilter(types.ChatType.GROUP), AdminFilter())
async def warn_user(message: types.Message, state: FSMContext):
    # Получаем информацию о пользователе, которого нужно предупредить
    if message.reply_to_message:
        user = message.reply_to_message.from_user
    else:
        await message.reply("Эту команду нужно использовать в ответ на сообщение пользователя.")
        return

    # Получаем информацию об администраторе, который отправил команду
    admin = await bot.get_chat_member(message.chat.id, message.from_user.id)

    # Получаем количество предупреждений у пользователя
    cursor.execute("SELECT count FROM warnings WHERE user_id=?", (user.id,))
    result = cursor.fetchone()

    # Если пользователь не был предупрежден ранее, то количество предупреждений равно 1
    if not result:
        count = 1
    else:
        count = result[0] + 1

    # Если количество предупреждений достигло максимального значения, то замьютим пользователя на 30 минут
    if count == 3:
        await bot.restrict_chat_member(chat_id=message.chat.id, user_id=user.id,
                                       permissions=ChatPermissions(can_send_messages=False,
                                                                     can_send_media_messages=False,
                                                                     can_send_other_messages=False), until_date=int(message.date.timestamp()) + 1800)

    # Обновляем количество предупреждений в базе данных
    update_warnings(user.id, await get_user_info(user), user.full_name, count)

    # Удаляем сообщение с командой /warn
    await message.delete()

    # Отправляем сообщение в чат
    await send_message(chat_id=message.chat.id,
                       text=f"Администратор {admin.user.username} предупредил Пользователя {await get_user_info(user)}. "
                            f"Сейчас у него {count} предупреждений.")

    # Устанавливаем состояние для удаления сообщения с командой /warn
    await state.set_state(WarnState.delete)

# Обработчик состояния для удаления сообщения с командой /warn
@dp.message_handler(state=WarnState.delete)
async def delete_warn_message(message: types.Message):
    await message.delete()
    await state.finish()

# info tour
@dp.message_handler(commands=['start'])
async def welcome_send_info(message: types.Message):
    await message.answer(f"{message.from_user.full_name}, привет!\n\n"
                         f"Это бот модератор, для использования добавьте бота в ваш чат со стандартными разрешениями"
                         f" админа, иначе бот не сможет функционировать\n\n"
                         f"Команды для администраторов:\n\n"
                         f" <code>!ban</code> (reason)- бан пользователя и удаление его из чата\n"
                         f" <code>!mute10m</code> (30m, 1h, 6h, 1d)- запретить "
                         f"пользователю отправлять сообщение в чат в указанное время (минуты, часы, дни)\n"
                         f"<code>!unmute</code> - разрешить отправку сообщений\n"
                         f"<code>!del</code> - удалить сообщение\n"
                         f"<code>!pin</code> - закрепить сообщение\n"
                         f"<code>!unpin</code> - открепить сообщение\n"
                         f"<code>!unpin_all</code> - открепить все сообщения в чате\n\n"
                         f"❗Все команды кроме последней, нужно отправлять ответом на сообщение пользователя!\n\n"
                         f"Бота сделал @svelllll")


# new chat member
@dp.message_handler(content_types=["new_chat_members"])
async def new_chat_member(message: types.Message):
    chat_id = message.chat.id
    await bot.delete_message(chat_id=chat_id, message_id=message.message_id)
    await bot.send_message(chat_id=chat_id, text=f"[{message.new_chat_members[0].full_name}]"
                                                 f"(tg://user?id={message.new_chat_members[0].id})"
                                                 f"Приветствуем тебя в Svell Shop! Перед общением в чате, прочитай правила в теме Rules, или введи команду <code>/rules</code> в чате. Приятного общения!", parse_mode=types.ParseMode.MARKDOWN)


# delete message user leave chat
@dp.message_handler(content_types=["left_chat_member"])
async def leave_chat(message: types.Message):
    await bot.delete_message(chat_id=message.chat.id, message_id=message.message_id)


@dp.message_handler(commands=['rules'])
async def send_rules(message: types.Message):
    # здесь можно указать свой текст правил
    rules_text = """<i><b>❗️ Правила Svell Shop ❗️
1️⃣ Запрещается:
   • Оскорбление администрации [Варн/Мут 1 час]
   • Спам/Флуд [Варн/Мут 30 мин]
   • 18+ Стикеры/Гифки/Фото/Видео [Варн/Мут 1 час]
   • Обсуждение политики [Варн]
   • Отправлять нежелательные файлы (вирусы, и т.п.) [Бан 3 дня]
   • Реклама проектов помимо Svell Shop [Бан 1 день]
2️⃣ Отступы в правилах:
   • Разрешено Флудить если вам понадобится для игры в BFG
3️⃣ Остальное:
   • Не знание правил не оставляет вас без ответственности.
   • Правила могут изменяться в любой момент.
   • Администрация в праве, выдать наказание на своё усмотрение.</b></i>"""
    await message.reply(rules_text, parse_mode="HTML")

CHANNEL_ID = '-1001897389997'

@dp.message_handler(AdminFilter(is_chat_admin=True), commands=['all'], chat_type=[types.ChatType.SUPERGROUP, types.ChatType.GROUP])
async def send_to_all(message: types.Message):
    # Получаем текст сообщения
    message_text = message.text.split('/all ')[1]
   
    # Отправляем сообщение в канал
    await bot.send_message(chat_id=CHANNEL_ID, text=message_text)
   
    # Отправляем сообщение в чат
    sent_message = await bot.send_message(chat_id=message.chat.id, text=message_text)
    
    # Закрепляем сообщение в чате
    await bot.pin_chat_message(chat_id=message.chat.id, message_id=sent_message.message_id)

# user get info about him
@dp.message_handler(chat_type=[types.ChatType.SUPERGROUP, types.ChatType.GROUP], commands=['me'])
async def welcome(message: types.Message):
    if message.from_user.username is None:
        await message.reply(f"Name - {message.from_user.full_name}\nID - {message.from_user.id}\n")
    else:
        await message.reply(f"Имя - {message.from_user.full_name}\n"
                            f"ID - <code>{message.from_user.id}</code>\n"
                            f"Тег - @{message.from_user.username}\n")


# ban user
@dp.message_handler(AdminFilter(is_chat_admin=True), IsReplyFilter(is_reply=True), commands=['ban'],
                    commands_prefix='!', chat_type=[types.ChatType.SUPERGROUP, types.ChatType.GROUP])
async def ban(message: types.Message):
    replied_user = message.reply_to_message.from_user.id
    admin_id = message.from_user.id
    await bot.kick_chat_member(chat_id=message.chat.id, user_id=replied_user)
    await bot.delete_message(chat_id=message.chat.id, message_id=message.message_id)
    await bot.send_message(chat_id=message.chat.id, text=f"[{message.reply_to_message.from_user.full_name}]"
                                                         f"(tg://user?id={replied_user})"
                                                         f" был забанен админом [{message.from_user.full_name}]"
                                                         f"(tg://user?id={admin_id})",
                           parse_mode=types.ParseMode.MARKDOWN)


# mute user in chat
@dp.message_handler(AdminFilter(is_chat_admin=True), IsReplyFilter(is_reply=True), commands=['mute'],
                    chat_type=[types.ChatType.SUPERGROUP, types.ChatType.GROUP])
async def mute(message: types.Message):
    args = message.text.split()

    if len(args) > 1:
        till_date = message.text.split()[1]
    else:
        till_date = "1m"

    if till_date[-1] == "m":
        ban_for = int(till_date[:-1]) * 60
    elif till_date[-1] == "h":
        ban_for = int(till_date[:-1]) * 3600
    elif till_date[-1] == "d":
        ban_for = int(till_date[:-1]) * 86400
    else:
        ban_for = 1 * 60

    replied_user = message.reply_to_message.from_user.id
    now_time = int(time.time())
    await bot.restrict_chat_member(chat_id=message.chat.id, user_id=replied_user,
                                   permissions=types.ChatPermissions(can_send_messages=False,
                                                                     can_send_media_messages=False,
                                                                     can_send_other_messages=False),
                                   until_date=now_time + ban_for)
    await bot.delete_message(chat_id=message.chat.id, message_id=message.message_id)
    await bot.send_message(text=f"[{message.reply_to_message.from_user.full_name}](tg://user?id={replied_user})"
                                f" замучен на  {till_date}",
                           chat_id=message.chat.id, parse_mode=types.ParseMode.MARKDOWN)



@dp.message_handler(content_types=['text'])
async def delete_links(message: types.Message):
    admins_list = [admin.user.id for admin in await bot.get_chat_administrators(chat_id=message.chat.id)]
    if message.from_user.id not in admins_list:

        for entity in message.entities: #Удаление сообщений с ссылками
            if entity.type in ["url", "text_link"]:
                await bot.delete_message(message.chat.id, message.message_id)
                await bot.send_message(message.chat.id, "Eсли Вы хотите отправлять ссылки со своей рекламой, обратитесь к администратору @svell_lzt")

# Определяем состояния
class ChatState(StatesGroup):
    waiting_for_message = State()

# Обработчик сообщений
@dp.message_handler(Text(equals=["копать железо", "копать алмазы"]))
async def handle_exception(message: types.Message):
    await message.answer("Вы можете продолжать писать сообщения")

# Обработчик сообщений
@dp.message_handler(state=ChatState.waiting_for_message)
async def handle_message(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        # Если это первое сообщение, то сохраняем его
        if "last_message" not in data:
            data["last_message"] = message.text
        # Если это второе сообщение и оно совпадает с предыдущим, то сохраняем его
        elif "last_message" in data and data["last_message"] == message.text:
            data["last_message"] = message.text
        # Если это третье сообщение и оно совпадает с предыдущими двумя, то удаляем все три сообщения и мутируем пользователя на 15 минут
        elif "last_message" in data and data["last_message"] == message.text:
            await message.delete()
            await bot.restrict_chat_member(message.chat.id, message.from_user.id, ChatPermissions(), until_date=message.date + 900)
            data["last_message"] = None
        # Если это третье сообщение, но оно не совпадает с предыдущими двумя, то сохраняем его и начинаем заново
        else:
            data["last_message"] = message.text

    # Устанавливаем состояние ожидания следующего сообщения
    await ChatState.waiting_for_message.set()

# Обработчик ошибок
@dp.errors_handler(exception=Exception)
async def handle_errors(update, exception):
    print(exception)

# random mute chat memberекгнкен
@dp.message_handler(chat_type=[types.ChatType.SUPERGROUP, types.ChatType.GROUP], commands=['dont_click_me'])
async def mute_random(message: types.Message):
    now_time = int(time.time())
    replied_user_id = message.from_user.id
    replied_user = message.from_user.full_name
    random_m = randint(1, 10)
    await bot.restrict_chat_member(chat_id=message.chat.id, user_id=replied_user_id,
                                   permissions=types.ChatPermissions(can_send_messages=False,
                                                                     can_send_media_messages=False,
                                                                     can_send_other_messages=False),
                                   until_date=now_time + 60 * random_m)
    await bot.send_message(text=f"[{replied_user}](tg://user?id={replied_user_id})"
                                f" выиграл(а) мут на {random_m} минут(ы)",
                           chat_id=message.chat.id, parse_mode=types.ParseMode.MARKDOWN)


# un_mute user in chat
@dp.message_handler(AdminFilter(is_chat_admin=True), IsReplyFilter(is_reply=True),
                    chat_type=[types.ChatType.SUPERGROUP, types.ChatType.GROUP], commands=['unmute'])
async def un_mute_user(message: types.Message):
    replied_user = message.reply_to_message.from_user.id
    await bot.restrict_chat_member(chat_id=message.chat.id, user_id=replied_user,
                                   permissions=types.ChatPermissions(can_send_messages=True,
                                                                     can_send_media_messages=True,
                                                                     can_send_other_messages=True),)
    await bot.delete_message(chat_id=message.chat.id, message_id=message.message_id)
    await bot.send_message(text=f"[{message.reply_to_message.from_user.full_name}](tg://user?id={replied_user})"
                                f" можешь теперь писать в чат )",
                           chat_id=message.chat.id, parse_mode=types.ParseMode.MARKDOWN)


# pin chat message
@dp.message_handler(AdminFilter(is_chat_admin=True), IsReplyFilter(is_reply=True),
                    chat_type=[types.ChatType.SUPERGROUP, types.ChatType.GROUP], commands=['pin'])
async def pin_message(message: types.Message):
    msg_id = message.reply_to_message.message_id
    await bot.pin_chat_message(message_id=msg_id, chat_id=message.chat.id)


# unpin chat message
@dp.message_handler(AdminFilter(is_chat_admin=True), IsReplyFilter(is_reply=True),
                    chat_type=[types.ChatType.SUPERGROUP, types.ChatType.GROUP], commands=['unpin'])
async def unpin_message(message: types.Message):
    msg_id = message.reply_to_message.message_id
    await bot.unpin_chat_message(message_id=msg_id, chat_id=message.chat.id)


# unpin all pins
@dp.message_handler(AdminFilter(is_chat_admin=True), IsReplyFilter(is_reply=True),
                    chat_type=[types.ChatType.SUPERGROUP, types.ChatType.GROUP], commands=['unpin_all'])
async def unpin_all_messages(message: types.Message):
    await bot.unpin_all_chat_messages(chat_id=message.chat.id)


# delete user message
@dp.message_handler(AdminFilter(is_chat_admin=True), IsReplyFilter(is_reply=True),
                    chat_type=[types.ChatType.SUPERGROUP, types.ChatType.GROUP], commands=['del'])
async def delete_message(message: types.Message):
    msg_id = message.reply_to_message.message_id
    await bot.delete_message(chat_id=message.chat.id, message_id=msg_id)
    await bot.delete_message(chat_id=message.chat.id, message_id=message.message_id)


# get chat admins list
@dp.message_handler(chat_type=[types.ChatType.SUPERGROUP, types.ChatType.GROUP], commands=['admins'], state="*")
async def get_admin_list(message: types.Message, state: FSMContext):
    admins = await message.chat.get_administrators()
    msg = str("Админы :\n")
    
    for admin in admins:
        msg += f"Тег и ник администратора: <a href='tg://user?id={admin.user.id}'>{admin.user.full_name}</a>\n"
        
    await message.reply(msg, parse_mode="HTML")


# report about spam or something else
@dp.message_handler(chat_type=[types.ChatType.SUPERGROUP, types.ChatType.GROUP], commands=['report'])
async def report_by_user(message: types.Message):
    msg_id = message.reply_to_message.message_id
    user_id = message.from_user.id
    admins_list = await message.chat.get_administrators()

    for admin in admins_list:
        try:
            await bot.send_message(text=f"User: [{message.from_user.full_name}](tg://user?id={user_id})\n"
                                        f"Reported about next message:\n"
                                        f"[Возможное нарушение](t.me/{message.chat.username}/{msg_id})",
                                   chat_id=admin.user.id, parse_mode=types.ParseMode.MARKDOWN,
                                   disable_web_page_preview=True)
        except Exception as e:
            logging.debug(f"\nCan't send report message to {admin.user.id}\nError - {e}")

    await message.reply("Я отправил информацию администраторам, которая может нарушать правила чата. Спасибо что делаете наш чат лучше.")



# Polling
if __name__ == '__main__':
    executor.start_polling(dp, on_startup=send_adm, skip_updates=True)
