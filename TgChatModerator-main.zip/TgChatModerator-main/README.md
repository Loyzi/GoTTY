# TelegramChatModerator
Bot moderator for your telegram chat

Русский

Это бот модератор, для использования добавьте бота в ваш чат со стандартными разрешениями админа, иначе бот не сможет функционировать</br>
Команды для администраторов:</br>
!ban - бан пользователя и удаление его из чата</br>
!mute (m, h, d)- запретить пользователю отправлять сообщение в чат указанное время (минуты, часы, дни)</br>
!unmute - разрешить отправку сообщений</br>
!del - удалить сообщение</br>
!pin - закрепить сообщение</br>
!unpin - открепить сообщение</br>
!unpin_all - открепить все сообщения в чате</br>
❗Все команды кроме последней, нужно отправлять ответом на сообщение пользователя!</br>
Бота сделал @mr_storm</br>
</br>
####################################################################################</br>
</br>
English</br>
</br>
This is a bot moderator, to use add the bot to your chat with standard admin permissions, otherwise the bot will not be able to function</br>
Commands for administrators:</br>
! ban - ban the user and remove him from the chat</br>
! mute (m, h, d) - prohibit the user from sending a message to the chat at the specified time (minutes, hours, days)</br>
! unmute - allow sending messages</br>
! del - delete a message</br>
! pin - pin the message</br>
! unpin - unpin the message</br>
! unpin_all - unpin all chat messages</br>
❗All commands except the last one must be sent as a reply to the user's message!</br>
Bot made by @mr_storm</br>
