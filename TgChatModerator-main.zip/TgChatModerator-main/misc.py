import logging

# Logging
from aiogram import Bot, Dispatcher, types

from config import token

logging.basicConfig(level=logging.INFO)

# Bot configs
bot = Bot(token="6021146296:AAFnsYz2s2-Rq6JpuCWiRoOgof1LTotBnnA", parse_mode="HTML")
dp = Dispatcher(bot)
